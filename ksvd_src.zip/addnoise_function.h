#ifndef _ADD_NOISE_FUNCTION_H_
#define _ADD_NOISE_FUNCTION_H_


#include <cmath>

void fiAddNoise(float *u, double *v, double std, long int randinit, unsigned size);

#endif
